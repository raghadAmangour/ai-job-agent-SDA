# Phase 5 outputs — Data Dictionary

## live_candidate/matched_jobs.parquet

One row per job that survived Phase 4, ordered by deterministic field-by-field
candidate match. All columns from `filtered_jobs.parquet` are preserved.

### Ranking and hand-off
| Column | Notes |
|---|---|
| phase5_rank | 1 = highest Phase 5 match. Contiguous, no gaps. |
| candidate_id | Candidate foreign key copied from Phase 2. |
| match_score | Equal-weight mean of active non-redundant evidence criteria in [0,100]; an absolute, parameter-free baseline. |
| objective_rank_score | CRITIC-weighted score in [0,100], used for Phase 5 ordering. Weights are learned from contrast/correlation in this candidate's surviving pool. |
| scoring_coverage | Fraction of the five ranking criteria supported by stated job fields. |
| scoring_confidence | Coverage × evidence reliability × source extraction confidence, in [0, 1]. |
| is_phase6_candidate | True for the leading pool that Phase 6 should re-rank. |
| similarity | Phase 3 cosine similarity, carried unchanged as an independent Phase 6 signal. |

### Component scores
The five independent ranking criteria are `core_skills_score`,
`languages_score`, `experience_fit_score`, `education_field_score`, and
`qualifications_score`. Diagnostic fields preserve required/preferred and
bucket-level skill coverage, ordinal/numeric experience, and education-level
eligibility. Education level does not enter Phase 5 scoring because Phase 4
already enforced it; degree phrases are likewise removed from professional
qualifications to prevent double-counting. Null criteria are unassessed rather than zero.

### Evidence for Phase 7
The `matched_*` and `missing_*` list columns are factual evidence for later
LLM explanations. `match_evidence_json` is the same evidence in a portable
JSON string. `component_scores_json`, `effective_weights_json`, and
`critic_weights_json` preserve both the equal and objective weighting paths.

## live_candidate/matching_summary.csv

Human-readable subset for quick inspection. List fields are pipe-delimited.
The Parquet file remains the authoritative machine-readable output.

## run_metadata.json

Run identifier, candidate id, row counts, scoring version and complete CONFIG.

## Phase 6 contract
- Read `matched_jobs.parquet`; do not recompute Phase 5 components.
- Re-rank rows where `is_phase6_candidate == True` (default: top 50).
- Keep `objective_rank_score`, `match_score`, `similarity`, `scoring_confidence`, and evidence columns.
- A cross-encoder/model score may be fused with these independent signals.
- Phase 6 outputs the final top 10-20 jobs for Phase 7 explanation.

## Matching contract
- No embeddings or LLM calls are made in Phase 5.
- Skill matching is weighted recall using Phase 1/2 `*_norm` fields and Phase 1 IDF.
- Missing job requirements are unassessed, not scored as zero.
- Experience uses the explicit years ratio when available; otherwise normalized ordinal distance.
- Education has no 70/30 split: level is diagnostic, field relevance is a separate criterion.
- No subjective fixed component weights or phrase thresholds are used.
- Phase 3 `similarity` is a tie-breaker only and is not part of either Phase 5 score.
