# Phase 6 outputs — Data Dictionary

## live_candidate/reranked_jobs.parquet

One row per Phase 5 pool job. All Phase 5 columns and factual evidence are
preserved. No job filtered out before Phase 6 can re-enter the result.

| Column | Notes |
|---|---|
| phase6_rank | Final Phase 6 rank, contiguous from 1. |
| reranker_raw_score | Cross-Encoder logit used for ordering. Not a probability. |
| reranker_percentile | Within-pool percentile for display only. Not a match probability. |
| rank_change | phase5_rank - phase6_rank; positive means the job moved up. |
| rerank_status | success / no_comparison_pool / fallback_phase5 / empty_input. |
| pair_token_count | Untruncated tokenizer length for the candidate/job pair. |
| input_was_truncated | True when the pair exceeded CONFIG max_pair_tokens. |
| cache_hit | True when the exact model/candidate/job score was reused. |
| inference_time_ms | Approximate per-pair time for newly inferred batches. |
| reranker_model / reranker_revision | Immutable model provenance. |

## live_candidate/reranking_summary.csv

Human-readable rank comparison and principal matching evidence. The Parquet
file is authoritative.

## live_candidate/final_top_jobs.json

Privacy-safe Phase 7 payload containing at most CONFIG final_top_n jobs, full
job descriptions, scores, and factual matched/missing evidence. It contains
candidate_id but no candidate name, email, phone, source filename, or full
candidate profile.

## reranker_cache.jsonl

One JSON record per exact candidate-text/job-text/model/revision hash. Upload
this file with Phase 5 inputs to reuse scores on an identical rerun.

## Re-ranking contract
- The Cross-Encoder score is primary; Phase 5/3 signals break exact ties.
- No fixed manual fusion weights are used.
- Raw logits are relevance scores, not probabilities.
- A one-job pool is scored but receives no_comparison_pool.
- Any model/load/inference failure preserves Phase 5 ordering.
- Phase 7 explains the final jobs; Phase 6 generates no user-facing prose.
